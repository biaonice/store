import { Component } from '@angular/core';

@Component({
  selector: 'shopping-cart',
  templateUrl: './../template/shopping-cart.component.html',
  styleUrls: [ './../style/shopping-cart.component.css' ]
})
export class ShoppingCartComponent  { }