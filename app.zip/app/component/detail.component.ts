import { Component } from '@angular/core';

@Component({
  selector: 'app-detail',
  template:
    `
		<h3>345</h3>
  	`
})
export class DetailComponent  { }