import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'user-info',
	templateUrl: './../template/user-info.component.html',
	styleUrls: [ './../style/user-info.component.css' ]
})
export class UserInfoComponent {
	  title= 'Tour of Heroes';
}