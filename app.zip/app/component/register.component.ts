import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-register',
	templateUrl: './../template/register.component.html',
	styleUrls: [ './../style/register.component.css' ]
})
export class RegisterComponent {
 }