import { Component } from '@angular/core';

@Component({
  selector: 'book-detail',
  templateUrl: './../template/book-detail.component.html',
  styleUrls: ['./../style/book-detail.component.css']
})
export class BookDetailComponent  { }