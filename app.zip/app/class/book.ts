export class Book {
	id:number;
	name:string;
	author:string;
	publish:string;
	publishtime:string;
	summery:string;
	price:number;
	edtion:number;
}