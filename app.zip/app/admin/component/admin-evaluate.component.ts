import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'admin-evaluate',
	templateUrl: './../template/admin-evaluate.component.html',
	styleUrls: [ './../style/admin-evaluate.component.css' ]
})
export class AdminEvaluateComponent {
	  title= '';
}