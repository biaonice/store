import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'admin-order',
	templateUrl: './../template/admin-order.component.html',
	styleUrls: [ './../style/admin-order.component.css' ]
})
export class AdminOrderComponent {
	  title= '';
}