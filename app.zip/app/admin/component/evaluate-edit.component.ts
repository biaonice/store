import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'admin-evaluate',
	templateUrl: './../template/evaluate-edit.component.html',
	styleUrls: [ './../style/evaluate-edit.component.css' ]
})
export class EvaluateEditComponent {
	  title= '';
}