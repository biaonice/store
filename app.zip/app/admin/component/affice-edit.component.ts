import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'admin-evaluate',
	templateUrl: './../template/affice-edit.component.html',
	styleUrls: [ './../style/affice-edit.component.css' ]
})
export class AfficeEditComponent {
	  title= '';
}