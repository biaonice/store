import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'admin-evaluate',
	templateUrl: './../template/affice-add.component.html',
	styleUrls: [ './../style/affice-add.component.css' ]
})
export class AfficeAddComponent {
	  title= '';
}