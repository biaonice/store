import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'admin-evaluate',
	templateUrl: './../template/user-edit.component.html',
	styleUrls: [ './../style/user-edit.component.css' ]
})
export class UserEditComponent {
	  title= '';
}