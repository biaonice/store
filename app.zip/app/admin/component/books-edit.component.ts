import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'admin-evaluate',
	templateUrl: './../template/Books-edit.component.html',
	styleUrls: [ './../style/Books-add.component.css' ]
})
export class BooksEditComponent {
	  title= '';
}