import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'admin-affice',
	templateUrl: './../template/admin-affice.component.html',
	styleUrls: [ './../style/admin-affice.component.css' ]
})
export class AdminAfficeComponent {
	  title= '';
}