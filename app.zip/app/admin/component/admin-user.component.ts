import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'admin-user',
	templateUrl: './../template/admin-user.component.html',
	styleUrls: [ './../style/admin-user.component.css' ]
})
export class AdminUserComponent {
	  title= '';
}